<?php
session_start();
require 'db.php';
require 'vendor/autoload.php';

use Razorpay\Api\Api;

$api_key = "rzp_test_weWkTdxTnwUghx";
$api_secret = "7ujDworqXqupNSitmjSpsa8M";

$api = new Api($api_key, $api_secret);

if (!isset($_SESSION['customer_data'])) {
    header("Location: customer_login.php");
    exit();
}

$customer = $_SESSION['customer_data'];
$customer_id = $customer['id'];

$cart_items = $_SESSION['cart'] ?? [];
$total_amount = 0;

foreach ($cart_items as $product_id => $quantity) {
    $stmt = $conn->prepare("SELECT product_price FROM products WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $total_amount += $result['product_price'] * $quantity;
}

$orderData = [
    'receipt' => uniqid(),
    'amount' => $total_amount * 100, // Convert to paise
    'currency' => 'INR',
    'payment_capture' => 1
];

$order = $api->order->create($orderData);
$order_id = $order['id'];

// Store order_id in session for verification
$_SESSION['razorpay_order_id'] = $order_id;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Checkout</title>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
</head>
<body>
    <h2>Total Amount: ₹<?php echo number_format($total_amount, 2); ?></h2>
    <button id="pay-btn">Pay Now</button>

    <script>
        var options = {
            "key": "<?php echo $api_key; ?>",
            "amount": "<?php echo $total_amount * 100; ?>",
            "currency": "INR",
            "name": "Natural Farming Marketplace",
            "order_id": "<?php echo $order_id; ?>",
            "handler": function (response) {
                fetch('verify_payment.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        razorpay_payment_id: response.razorpay_payment_id,
                        razorpay_order_id: response.razorpay_order_id,
                        razorpay_signature: response.razorpay_signature,
                        customer_id: "<?php echo $customer_id; ?>"
                    })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        alert('Payment Successful');
                        window.location.href = "order_success.php";
                    } else {
                        alert('Payment Failed: ' + data.message);
                    }
                });
            },
            "prefill": {
                "name": "<?php echo htmlspecialchars($customer['full_name']); ?>",
                "email": "<?php echo htmlspecialchars($customer['email']); ?>",
                "contact": "<?php echo htmlspecialchars($customer['phone']); ?>"
            },
            "theme": { "color": "#F37254" }
        };

        document.getElementById('pay-btn').onclick = function () {
            var rzp = new Razorpay(options);
            rzp.open();
        };
    </script>
</body>
</html>
