<?php
echo "<h2>Payment Successful! Your order has been placed.</h2>";
?>
