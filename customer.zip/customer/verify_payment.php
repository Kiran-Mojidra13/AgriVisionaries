<?php
session_start();
require 'db.php';
require 'vendor/autoload.php';

use Razorpay\Api\Api;

$api_key = "rzp_test_weWkTdxTnwUghx";
$api_secret = "7ujDworqXqupNSitmjSpsa8M";

$api = new Api($api_key, $api_secret);

$data = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($data['razorpay_payment_id'], $data['razorpay_order_id'], $data['razorpay_signature'], $data['customer_id'])) {
    echo json_encode(["success" => false, "message" => "Invalid request."]);
    exit();
}

$payment_id = $data['razorpay_payment_id'];
$order_id = $data['razorpay_order_id'];
$signature = $data['razorpay_signature'];
$customer_id = (int) $data['customer_id'];

// Check if session order_id matches received order_id
if (!isset($_SESSION['razorpay_order_id']) || $_SESSION['razorpay_order_id'] !== $order_id) {
    echo json_encode(["success" => false, "message" => "Order ID mismatch."]);
    exit();
}

try {
    $attributes = [
        'razorpay_order_id' => $order_id,
        'razorpay_payment_id' => $payment_id,
        'razorpay_signature' => $signature
    ];
    $api->utility->verifyPaymentSignature($attributes);

    $cart_items = $_SESSION['cart'] ?? [];

    foreach ($cart_items as $product_id => $quantity) {
        $stmt = $conn->prepare("SELECT product_price, farmer_id FROM products WHERE product_id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $total_price = $result['product_price'] * $quantity;
        $farmer_id = $result['farmer_id'];

        $order_stmt = $conn->prepare("INSERT INTO orders (customer_id, farmer_id, product_id, quantity, total_price, order_status, payment_status, payment_method, razorpay_payment_id) 
                                      VALUES (?, ?, ?, ?, ?, 'Pending', 'Completed', 'Razorpay', ?)");
        $order_stmt->bind_param("iiiids", $customer_id, $farmer_id, $product_id, $quantity, $total_price, $payment_id);
        $order_stmt->execute();

        // Reduce stock
        $update_stock = $conn->prepare("UPDATE products SET stock = stock - ? WHERE product_id = ?");
        $update_stock->bind_param("ii", $quantity, $product_id);
        $update_stock->execute();
    }

    // Clear cart
    unset($_SESSION['cart']);
    unset($_SESSION['razorpay_order_id']);

    echo json_encode(["success" => true]);
} catch (\Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>
