<?php
date_default_timezone_set('Asia/Kolkata');
include('database.inc.php');

if (isset($_POST['txt'])) {
    $txt = mysqli_real_escape_string($con, $_POST['txt']);

    // SQL query with parameterized statement
    $sql = "SELECT reply FROM chatbot WHERE question LIKE ?";
    
    // Prepare the SQL statement
    $stmt = mysqli_prepare($con, $sql);
    
    if ($stmt === false) {
        // If statement preparation fails, show an error message
        die('Error preparing the SQL query: ' . mysqli_error($con));
    }

    // Bind the parameter
    $search_txt = "%" . $txt . "%";
    mysqli_stmt_bind_param($stmt, "s", $search_txt);

    // Execute the statement
    mysqli_stmt_execute($stmt);

    // Get the result
    $res = mysqli_stmt_get_result($stmt);

    if ($res && mysqli_num_rows($res) > 0) {
        $row = mysqli_fetch_assoc($res);
        $html = $row['reply'];
    } else {
        $html = "Sorry, I couldn't understand your question. Can you please rephrase it?";
    }

    // Insert user's message into the chat table
    $added_on = date('Y-m-d h:i:s');
    mysqli_query($con, "INSERT INTO chatbot(chatbot, added_on, type) VALUES('$txt', '$added_on', 'user')");
    
    // Insert bot's reply into the chat table
    $added_on = date('Y-m-d h:i:s');
    mysqli_query($con, "INSERT INTO chatbot(chatbot, added_on, type) VALUES('$html', '$added_on', 'bot')");

    // Output the bot's reply
    echo $html;

    // Close the prepared statement
    mysqli_stmt_close($stmt);
} else {
    echo "Error: No message received.";
}
?>
